<?php
header('location:paginas/login.php');