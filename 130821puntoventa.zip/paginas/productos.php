
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="css/main.css">
<?php
include('modulos/header.php')
?>

 <h2>Productos</h2>
<div class="opc-menu-card">
  <a href="form/frmNuevoProducto.php" class="card-menu">
    <span class="card-img">
      &#9997;
    </span>
    <span class="card-text">
      Crear nuevo
    </span>
  </a>
  <a href="form/lstProductos.php" class="card-menu">
    <span class="card-img">
      &#128203;
    </span>
    <span class="card-text">
      Listar
    </span>
  </a>
   <a href="" class="card-menu">
     <span class="card-img">
       &#128373;
     </span>
     <span class="card-text">
       Buscar
     </span>
   </a>
</div>

  
