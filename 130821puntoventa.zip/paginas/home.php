
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<?php
include('modulos/header.php');

if (isset($_GET['ruta'])) {
  if ($_GET['ruta']=='form/frmNuevoProducto.php') {
    var_dump($_GET['ruta']);
  }
}
else {
    var_dump($_GET['ruta']);
  echo 'error url';
}
?>

<h1>
  &#9997;
  &#128101;
  &#128195;
  &#128203;
  &#128221;
  &#128209;
  &#128269;
  &#128270;
  &#128373;
  &#128466;
  &#128666;
  &#128667;
  &#128717;
  &#128722;
</h1>