
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
<link rel="stylesheet" href="css/login.css" />
<div class="login-container">
  <form action="control/vldlogin.php" method="post">
    <fieldset>
      <legend>Ingreso a Punto de Ventas</legend>
        <input type="text" name="user" class="control-form" placeholder="Usuario">
        <input type="password" name="pass" class="control-form" placeholder="Contraceña">
        <button type="submit" class="btn control-form">Ingresar</button>
    </fieldset>
  </form>
</div>

