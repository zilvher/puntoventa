<!-- <link rel="stylesheet" href="css/header.css"> -->
<header>
  <nav class="navbar">
    <a href="" class="logo">
      <strong>P</strong>unto
      <strong>V</strong>enta
    </a>
    <ul>
      <li>
        <a href="../productos.php" class="link">Productos</a>
      </li>
      <li>
        <a href="../clientes.php" class="link">Clientes</a>
      </li>
      <li>
        <a href="" class="link">Ventas</a>
      </li>
    </ul>
  </nav>
</header>